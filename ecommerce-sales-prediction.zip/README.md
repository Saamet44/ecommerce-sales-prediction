
# E-Ticaret Satış Tahmin Sistemi

Bu proje, Azure SQL HyperScale ile entegre bir yapay zeka modeli kullanarak e-ticaret satışlarını tahmin etmeyi amaçlar.

## Özellikler
- Zaman serisi verileri işleyerek satış tahmini yapar.
- LSTM modeli ile ileriye dönük tahminler.
- Flask tabanlı API ile tahmin sonuçlarını sunar.

## Kurulum
1. Gerekli bağımlılıkları yükleyin:
   ```bash
   pip install -r requirements.txt
   ```
2. Flask uygulamasını çalıştırın:
   ```bash
   python app/app.py
   ```
3. Tahmin yapmak için API'yi çağırın:
   ```bash
   GET http://127.0.0.1:5000/predict
   ```

## Lisans
Bu proje MIT lisansı ile lisanslanmıştır.
